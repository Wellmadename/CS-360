package com.example.comexamplegreetingcardar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PermissionsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    TextView textSendSms;
    Button backToLoginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);

        //Initialize All views
        textSendSms = findViewById(R.id.textSendSms);
        backToLoginButton = findViewById(R.id.backToLoginButton);

        //Handle Send SMS Click in Permissions Screen
        textSendSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkSmsPermission()) {
                    //Temp number but should be configured.
                    sendSms("1234567890", "This is a notification from your app.");
                } else {
                    //If not granted but not denied, request permission :)
                    requestSmsPermission();
                }
            }
        });

        //Handle Back to Login Button Click
        backToLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Navigate back to the MainActivity
                Intent intent = new Intent(PermissionsActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
    }

    //Checks SMS allowed or not duplicate. Don't need if I need it here but it worked.
    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    //SMS ASK duplicate. Don't need if I need it here but it worked.
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    //Send SMS tester.
    private void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent Successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    //SMS Permission Result notification in application!
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted! SMS notifications can be tested from the Permissions screen.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied. Please navigate to Application settings to enable.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}