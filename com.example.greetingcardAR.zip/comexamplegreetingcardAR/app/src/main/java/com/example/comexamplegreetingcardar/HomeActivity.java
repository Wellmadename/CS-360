package com.example.comexamplegreetingcardar;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.telephony.SmsManager;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    TextView userName;
    DatabaseHelper databaseHelper;
    Button logOut, addButton, addGoalWeightButton;
    EditText editTextWeight, editTextDate;
    TableLayout dataTable;
    int goalWeight = 0;
    boolean isSmsPermissionGranted = false;

    private static final int GOAL_WEIGHT_REQUEST_CODE = 200;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize all Views
        userName = findViewById(R.id.textUsername);
        logOut = findViewById(R.id.logOutButton);
        addGoalWeightButton = findViewById(R.id.addGoalWeightButton);
        editTextWeight = findViewById(R.id.editTextWeight);
        editTextDate = findViewById(R.id.editTextDate);
        addButton = findViewById(R.id.addButton);
        dataTable = findViewById(R.id.dataTableLayout);

        // Initialize the Database
        databaseHelper = new DatabaseHelper(this);

        // Display initial welcome message upon login
        String user = getIntent().getStringExtra("USERNAME");
        if (user != null) {
            userName.setText("Welcome " + user);
            loadData();
        }

        // Check for SMS permissions
        isSmsPermissionGranted = getIntent().getBooleanExtra("SMS_PERMISSION_GRANTED", false);

        // Add Data button functionality and logic.
        addButton.setOnClickListener(view -> {
            String weightStr = editTextWeight.getText().toString().trim();
            String date = editTextDate.getText().toString().trim();

            if (!weightStr.isEmpty() && !date.isEmpty()) {
                try {
                    int weight = Integer.parseInt(weightStr);
                    boolean result = databaseHelper.insertData(weight, date);

                    if (result) {
                        editTextWeight.setText("");
                        editTextDate.setText("");
                        loadData();

                        // SMS trigger check to send message if goal weight is hit.
                        if (goalWeight != 0 && weight == goalWeight && isSmsPermissionGranted) {
                            sendSms("1234567890", "Congratulations! You reached your goal weight of " + goalWeight);
                            Toast.makeText(HomeActivity.this, "Goal Weight Achieved!", Toast.LENGTH_SHORT).show();
                        } else {
                            // Otherwise just follow below logic.
                            Toast.makeText(HomeActivity.this, "Weight added to Tracker", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(HomeActivity.this, "Failed to add entry", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(HomeActivity.this, "Invalid weight value", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(HomeActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            }
        });

        // Add goal weight button functionality.
        addGoalWeightButton.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, GoalWeightActivity.class);
            startActivityForResult(intent, GOAL_WEIGHT_REQUEST_CODE);
        });

        // Logout Button
        logOut.setOnClickListener(view -> logOut());
    }

    /**
     * Handle Activity Results (Goal Weight)
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GOAL_WEIGHT_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            goalWeight = data.getIntExtra("GOAL_WEIGHT", 0);
            Toast.makeText(this, "Goal Weight Set: " + goalWeight, Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Send SMS Notification
     */
    private void sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Goal Weight Reached! Congrats!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // Data loading for the weight table.
    private void loadData() {
        Cursor cursor = databaseHelper.getAllData();

        // Clear Previous Rows
        dataTable.removeViews(1, Math.max(0, dataTable.getChildCount() - 1));

        if (cursor != null && cursor.moveToFirst()) {
            do {
                TableRow row = new TableRow(this);
                row.setLayoutParams(new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT
                ));

                String id = cursor.getString(cursor.getColumnIndexOrThrow("_id"));
                String weight = cursor.getString(cursor.getColumnIndexOrThrow("Weight"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("Date"));

                // Create TextViews (Header Columns)
                TextView idView = createTextView(id);
                TextView weightView = createTextView(weight);
                TextView dateView = createTextView(date);

                // Create Edit Button before delete button
                Button editButton = new Button(this);
                editButton.setText("Edit");
                editButton.setLayoutParams(new TableRow.LayoutParams(
                        14, // weight for sizing
                        TableRow.LayoutParams.WRAP_CONTENT,
                        1f
                ));
                editButton.setPadding(8, 8, 8, 8);
                editButton.setOnClickListener(view -> showEditDialog(id, weight, date));

                // Create Delete Button thats at the end of a row.
                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");
                deleteButton.setLayoutParams(new TableRow.LayoutParams(
                        200, // Weight for sizing
                        TableRow.LayoutParams.WRAP_CONTENT,
                        1f
                ));
                deleteButton.setPadding(8, 8, 8, 8);
                deleteButton.setOnClickListener(view -> {
                    int recordId = Integer.parseInt(id);
                    boolean deleted = databaseHelper.deleteData(recordId);

                    if (deleted) {
                        Toast.makeText(this, "Row Deleted", Toast.LENGTH_SHORT).show();
                        loadData();
                    } else {
                        Toast.makeText(this, "Deletion Failed", Toast.LENGTH_SHORT).show();
                    }
                });

                // Add All views to the row
                row.addView(idView);
                row.addView(weightView);
                row.addView(dateView);
                row.addView(editButton);
                row.addView(deleteButton);

                // Add a row to the Table
                dataTable.addView(row);

            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }
    }

    // Editable table logic popup after Edit button click.
    private void showEditDialog(String id, String currentWeight, String currentDate) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Weight Entry");

        final EditText inputWeight = new EditText(this);
        inputWeight.setHint("New Weight");
        inputWeight.setText(currentWeight);

        final EditText inputDate = new EditText(this);
        inputDate.setHint("New Date");
        inputDate.setText(currentDate);

        TableLayout dialogLayout = new TableLayout(this);
        dialogLayout.addView(inputWeight);
        dialogLayout.addView(inputDate);

        builder.setView(dialogLayout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newWeight = inputWeight.getText().toString().trim();
            String newDate = inputDate.getText().toString().trim();

            if (!newWeight.isEmpty() && !newDate.isEmpty()) {
                boolean updated = databaseHelper.updateData(Integer.parseInt(id), newWeight, newDate);

                if (updated) {
                    Toast.makeText(this, "Entry Updated", Toast.LENGTH_SHORT).show();
                    loadData();
                } else {
                    Toast.makeText(this, "Update Failed", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        builder.show();
    }

    // Text view with padding for our table
    private TextView createTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT,
                TableRow.LayoutParams.WRAP_CONTENT,
                1f
        ));
        textView.setGravity(android.view.Gravity.START);
        textView.setPadding(8, 8, 8, 8);
        return textView;
    }

    // Logout button logic.
    private void logOut() {
        Intent intent = new Intent(HomeActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
