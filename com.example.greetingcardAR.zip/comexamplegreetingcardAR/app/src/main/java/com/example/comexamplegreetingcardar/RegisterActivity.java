package com.example.comexamplegreetingcardar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    EditText username, password;
    TextView loginText;
    Button signUpButton;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.userNameText);
        password = findViewById(R.id.userNamePassword);
        loginText = findViewById(R.id.textLogin);
        signUpButton = findViewById(R.id.signUpButton);
        databaseHelper = new DatabaseHelper(this);

        loginText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        //Register Button Click Logic to move to Create user and move to HomeActivity. (In future could route to Login Again.
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();
                if(user.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Please Enter a proper Username and Password", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(databaseHelper.insertUserData(user,pass)) {
                        Toast.makeText(RegisterActivity.this, "Account Created, Welcome!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegisterActivity.this, HomeActivity.class);
                        intent.putExtra("USERNAME",user);
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(RegisterActivity.this, "Username Unavailable",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}