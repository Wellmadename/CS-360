package com.example.comexamplegreetingcardar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Login.db";
    private static final String TABLE_USERS = "Users";
    private static final String TABLE_WEIGHT = "WeightData";

    //Users Table Columns Data
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "USERNAME";
    private static final String COL_PASSWORD = "PASSWORD";

    //Weight Table Columns Data
    private static final String COL_WEIGHT_ID = "_id";
    private static final String COL_WEIGHT = "Weight";
    private static final String COL_DATE = "Date";

    //Database Constructor. Increment Version if new data needed OR uninstall re-install application.
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 3);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create a Users database Table
        db.execSQL("CREATE TABLE IF NOT EXISTS Users (_id INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)");

        //Create a Weight database Table
        db.execSQL("CREATE TABLE IF NOT EXISTS WeightData (_id INTEGER PRIMARY KEY AUTOINCREMENT, Weight INTEGER, Date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Users");
        db.execSQL("DROP TABLE IF EXISTS WeightData");
        onCreate(db);  //Recreates the database Tables
    }

    //Insert User data
    public boolean insertUserData(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    //Validate User logins
    public String checkLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL_USERNAME};
        String selection = COL_USERNAME + "=? AND " + COL_PASSWORD + "=?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        String result = null;
        if (cursor != null && cursor.moveToFirst()) {
            result = cursor.getString(cursor.getColumnIndexOrThrow(COL_USERNAME));
            cursor.close();
        }
        db.close();
        return result;
    }

    //Insert User weight data
    public boolean insertData(int weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_WEIGHT, weight);
        contentValues.put(COL_DATE, date);
        long result = db.insert(TABLE_WEIGHT, null, contentValues);
        return result != -1;
    }

    // Update Data by ID
    public boolean updateData(int id, String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_WEIGHT, weight);
        contentValues.put(COL_DATE, date);

        int result = db.update(TABLE_WEIGHT, contentValues, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }
    //Retrieve All present weight data from database
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHT, null);
    }

    //Delete weight data by ID when clicking Delete
    public boolean deleteData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_WEIGHT, COL_WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }
}

