package com.example.comexamplegreetingcardar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GoalWeightActivity extends AppCompatActivity {

    EditText goalWeightInput;
    Button saveGoalWeightButton, cancelButton;
    TextView currentGoalWeightDisplay;

    private static final String SHARED_PREFS = "GoalWeightPrefs";
    private static final String GOAL_WEIGHT_KEY = "goal_weight";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_weight);

        // Initialize all Views
        goalWeightInput = findViewById(R.id.goalWeightInput);
        saveGoalWeightButton = findViewById(R.id.saveGoalWeightButton);
        cancelButton = findViewById(R.id.cancelGoalWeightButton);
        currentGoalWeightDisplay = findViewById(R.id.currentGoalWeightDisplay);

        // Load and display the current goal weight
        loadGoalWeight();

        // Save weight goal logic.
        saveGoalWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goalWeight = goalWeightInput.getText().toString().trim();
                if (!goalWeight.isEmpty() && isValidGoalWeight(goalWeight)) {
                    saveGoalWeight(goalWeight);
                    returnToHome(Integer.parseInt(goalWeight));
                    goalWeightInput.setText("");  // Clear the input
                    Toast.makeText(GoalWeightActivity.this, "Goal Weight Set: " + goalWeight, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(GoalWeightActivity.this, "Please enter a valid weight.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle Cancel Button Click to return to HomeActivity
        cancelButton.setOnClickListener(view -> finish());
    }

    // Error catching for goal weight. Essentially make sure its the right data type.
    private boolean isValidGoalWeight(String goalWeight) {
        try {
            int weight = Integer.parseInt(goalWeight);
            return weight > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Save key-value pair for goalWeight in SharedPreferences to ensure persistence.
    private void saveGoalWeight(String goalWeight) {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(GOAL_WEIGHT_KEY, goalWeight);
        editor.apply();
    }

    // Ensure we can display goal weight in the square display, If not show No Goal Set.
    private void loadGoalWeight() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        String goalWeight = sharedPreferences.getString(GOAL_WEIGHT_KEY, "No Goal Set");
        currentGoalWeightDisplay.setText(goalWeight);
    }

    // Return back to HomeActivity once the goal weight is set.
    private void returnToHome(int goalWeight) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("GOAL_WEIGHT", goalWeight);
        setResult(RESULT_OK, resultIntent);
        finish();  // Close the Activity
    }
}
