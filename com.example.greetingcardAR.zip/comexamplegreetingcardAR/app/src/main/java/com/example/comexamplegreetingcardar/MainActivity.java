//Andrew Rapolevich SNHU
package com.example.comexamplegreetingcardar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;

    EditText username, password;
    TextView signUpText, sendSmsText;
    Button loginButton, permissionsButton;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize All views
        username = findViewById(R.id.userNameText);
        password = findViewById(R.id.userNamePassword);
        loginButton = findViewById(R.id.loginButton);
        signUpText = findViewById(R.id.textSignUp);
        permissionsButton = findViewById(R.id.permissionsButton);
        databaseHelper = new DatabaseHelper(this);

        //Check for SMS Permissions onCreate (App launch)
        if (!checkSmsPermission()) {
            showPermissionRequestPopup();
        }

        //Navigate to the Register Activity
        signUpText.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        //Takes care of Login Button Click
        loginButton.setOnClickListener(view -> handleLogin());

        //Navigates to Permissions Activity
        permissionsButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, PermissionsActivity.class);
            startActivity(intent);
        });
    }

    //Login Button Click logic (Validate User and pass)
    private void handleLogin() {
        String user = username.getText().toString().trim();
        String pass = password.getText().toString().trim();

        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Please enter a valid username and password", Toast.LENGTH_SHORT).show();
        } else {
            String loggedInUser = databaseHelper.checkLogin(user, pass);
            if (loggedInUser != null) {
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                intent.putExtra("USERNAME", loggedInUser);
                startActivity(intent);
                finish();  // Close MainActivity
            } else {
                Toast.makeText(this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Checks SMS allowed or not (Notify on Login)
    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    //SMS Permission Popup window
    private void showPermissionRequestPopup() {
        new AlertDialog.Builder(this)
                .setTitle("SMS Permission")
                .setMessage("GreetingCardAR requires SMS permissions to send weight notifications. Please allow access.")
                .setPositiveButton("Allow", (dialog, which) -> requestSmsPermission())
                .setNegativeButton("Deny", (dialog, which) -> {
                    dialog.dismiss();
                    // Handle denial of SMS permission. :(
                    Toast.makeText(MainActivity.this, "Permission Denied. Please navigate to Application settings to enable.", Toast.LENGTH_SHORT).show();
                })
                .setCancelable(false)
                .show();
    }
    //SMS ASK
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    //SMS Permission Result duplicate (I believe this is needed to be used for both use cases (Main screen or Permissions screen)).
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted! SMS notifications can be tested from the Permissions screen.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied. Please navigate to Application settings to enable.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}